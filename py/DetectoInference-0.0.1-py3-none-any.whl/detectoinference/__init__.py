# -*- coding: utf-8 -*-
"""
Created on Wed Mar 3 15:10:27 2023

@author: tarunsuresh.k
"""
import json
import time

import torch
from PIL.Image import Image
from PIL import Image
import base64
import io
import cv2
import numpy
from detecto.core import Model
from detecto.config import config as detecto_config


class Detecto:
    """CLass used for Object Detection which can detect 80 classes of the COCO dataset 2017 release"""
    def __init__(self, model_weight_file=None, model_name="fasterrcnn_resnet50_fpn", classes=None,
                 logger=None):
        """Initializing the Detecto Object detection module.

        Args:
            model_weight_file (str, None): The file location of the model weight(.pth file). (defaults is None, If None the model weight is downloaded and placed in torch cache folder when the Class in initialised for the first time in an environment)
            model_name (str): Model Name of the available 3 pretrained Torch model backbones. The accepted values are ('fasterrcnn_resnet50_fpn', 'fasterrcnn_mobilenet_v3_large_fpn', 'fasterrcnn_mobilenet_v3_large_320_fpn') (default is fasterrcnn_resnet50_fpn)
            classes (list, None): list of strings or integers that needs to be filtered from the Prediction. [] or None if all classes needs to be predicted.
            logger (None, logger object): Used for logging. (defaults to None)
        """
        device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
        self.model = Model(device=device, model_name=model_name)

        if model_weight_file is not None and model_weight_file != "":
            self.model.get_internal_model().load_state_dict(torch.load(model_weight_file, map_location=device))
            # print(file_name, " loaded")

        if classes == [] or classes is None:
            self.classes_gen = detecto_config['default_classes']
        elif len(classes) > 0:
            self.classes_gen = []
            default_classes = detecto_config['default_classes']
            for class_i in classes:
                if isinstance(class_i, int):
                    self.classes_gen.append(default_classes[class_i - 1])
                else:
                    self.classes_gen.append(class_i.lower())
        self.logger = logger
        if self.logger:
            self.logger.debug("device : " + str(device))
            self.logger.debug("Detecto model loaded successfully")

    def executeModel(self, base64_image, confidence_threshold=0.5):
        """Predict the objects present in an image.

        Args:
            base64_image (str): base64 encoding of an image
            confidence_threshold (float): confidence threshold for prediction. Ranges between 0.0 and 1.0 (defaults to 0.5)

        Returns:
            A List of dictionaries, each having 'Confidence Score', 'Label', 'Dimensions of bounding box'
        """
        image = Image.open(io.BytesIO(base64.b64decode(base64_image)))
        image = image.convert('RGB') if image.mode != 'RGB' else image
        width, height = image.size

        opencvImage = cv2.cvtColor(numpy.array(image), cv2.COLOR_RGB2BGR)

        st1 = time.time()
        predictions = self.model.predict(opencvImage)
        if self.logger:
            self.logger.info("Time taken for preprocessing " + str(time.time()-st1) + " seconds")

        output = []
        for i in range(len(predictions[2])):
            if predictions[2][i] >= float(confidence_threshold):
                if predictions[0][i] in self.classes_gen:
                    startx = float(predictions[1][i][0])
                    starty = float(predictions[1][i][1])
                    endx = float(predictions[1][i][2])
                    endy = float(predictions[1][i][3])
                    h = endy - starty
                    w = endx - startx
                    j = {}
                    j['Cs'] = round(float(predictions[2][i]), 2)
                    j['Lb'] = predictions[0][i]
                    j['Dm'] = {'X': round(startx / width, 8),
                               'Y': round(starty / height, 8),
                               'H': round(h / height, 8),
                               'W': round(w / width, 8)}
                    output.append(j)
        # print("out : ", output)
        # print("RC200")
        return output
